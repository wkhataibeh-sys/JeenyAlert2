package com.example.jeenyalert

import android.app.Notification
import android.app.NotificationManager
import android.app.NotificationChannel
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import java.util.Locale

class JeenyNotificationListener : NotificationListenerService() {
    private val threshold = 1.20
    private var lastAlertText = ""
    private var lastAlertAt = 0L

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val body = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val big = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
        val text = "$title $body $big".trim()
        if (text.isBlank()) return

        // Only alerts when notification text explicitly contains a Jordanian dinar amount.
        val normalized = text.replace(',', '.')
        val regex = Regex("(?i)(?:JOD|JD|دينار(?:\u0627\u0631\u062f\u0646\u064a)?|د\.أ)\\s*([0-9]+(?:\\.[0-9]{1,3})?)|([0-9]+(?:\\.[0-9]{1,3})?)\\s*(?:JOD|JD|د\.أ)")
        val match = regex.find(normalized) ?: return
        val amountText = match.groups[1]?.value ?: match.groups[2]?.value ?: return
        val amount = amountText.toDoubleOrNull() ?: return
        if (amount <= threshold) return

        val now = System.currentTimeMillis()
        if (text == lastAlertText && now - lastAlertAt < 5000) return
        lastAlertText = text
        lastAlertAt = now
        alertDriver()
    }

    private fun alertDriver() {
        try {
            val tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100)
            tone.startTone(ToneGenerator.TONE_PROP_BEEP2, 450)
            android.os.Handler(mainLooper).postDelayed({ tone.release() }, 600)
        } catch (_: Exception) { }
        try {
            val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE))
            else @Suppress("DEPRECATION") vibrator.vibrate(500)
        } catch (_: Exception) { }
    }
}
