package com.example.jeenyalert

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }
        layout.addView(TextView(this).apply {
            text = "تنبيه جيني\n\nالحد الحالي: أكثر من 1.20 دينار\n\nهذا نموذج أولي يقرأ نص الإشعارات فقط. إذا لم يظهر السعر في إشعار جيني فلن يستطيع هذا الإصدار قراءته من شاشة الطلب."
            textSize = 20f
            gravity = Gravity.CENTER
        })
        layout.addView(Button(this).apply {
            text = "تفعيل الوصول للإشعارات"
            setOnClickListener { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) }
        })
        layout.addView(TextView(this).apply {
            text = "بعد التفعيل، اختبر وصول إشعار طلب جديد. لا يتم قبول الطلب تلقائيًا."
            textSize = 15f
            gravity = Gravity.CENTER
            setPadding(0, 24, 0, 0)
        })
        setContentView(layout)
    }
}
